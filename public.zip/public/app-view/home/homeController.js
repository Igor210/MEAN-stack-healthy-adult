app.controller('HomeController', ['$rootScope','$scope', '$location','$window','FlashService', 'MetaService', '$modal', 'HttpService', function( $rootScope, $scope, $location, $window, FlashService, MetaService, $modal, HttpService ){
	$rootScope.loading = false;

    if(!$scope.vm) $scope.vm={};
    $scope.vm.pageSize = 100;
    $scope.vm.country = $rootScope.search.country || "Country";
    $scope.vm.state = $rootScope.search.state || "State";
    $scope.vm.region = $rootScope.search.region || "Region";
    $scope.vm.category = $rootScope.search.category || "Category";


    var vm = this;
	$rootScope.metaservice = MetaService;
	$rootScope.metaservice.set();
	$rootScope.savedPreference = $window.localStorage.getItem("healthyfling_preference");
	if ($rootScope.savedPreference == "locked") {
		$rootScope.search.country = $window.localStorage.getItem("healthyfling_preference_country") || "Country";
		$rootScope.search.state = $window.localStorage.getItem("healthyfling_preference_state") || "State";
		$rootScope.search.region = $window.localStorage.getItem("healthyfling_preference_region") || "Region";
		$rootScope.search.category = $window.localStorage.getItem("healthyfling_preference_category") || "Category";
	}
	vm.country = $rootScope.search.country || "Country";
	vm.state = $rootScope.search.state || "State";
	vm.region = $rootScope.search.region || "Region";
	vm.category = $rootScope.search.category || "Category";
	$scope.countries = $rootScope.countryList;
	$scope.states = $rootScope.stateList;
	$scope.regions = $rootScope.regionList;
	$scope.savedPreference = ($rootScope.savedPreference == "locked");
	vm.savedPreference = ($rootScope.savedPreference == "locked");
	if ($scope.regions && $scope.regions.indexOf("Region") == -1){
		$scope.regions.unshift("Region");
	}
	$scope.categories = $rootScope.categoryList;
	$scope.changeListInCtrl = function(data){
		if(data != "" && data != undefined && data != "State" && data != "Provinces"){
			$rootScope.regionList = $rootScope.masterList[data];

			$scope.regions = $rootScope.regionList;
			$scope.regions.unshift("Region");
			var temp = $scope.regions;
			$scope.regions = temp.filter(function(item, pos){
				return temp.indexOf(item)== pos;
			});
		}else{
			if (vm.country == "United States" || vm.country == "Canada") {
				$scope.regions = ['Region'];
			}
		}
	};
	$scope.changeStateListInCtrl = function(data){
		if(data != "" && data != undefined && data != "Country"){
			$rootScope.masterList = $rootScope.masterListAll[data];
			$rootScope.stateList = Object.keys($rootScope.masterListAll[data]);
			$scope.states = $rootScope.stateList;
			// $rootScope.regionList = $rootScope.masterListAll[data];

			if (data != "United States" && data != "Canada") {
				$rootScope.regionList = $rootScope.masterList["State"];
				$scope.regions = $rootScope.regionList;
				$scope.regions.unshift("Region");
				var temp = $scope.regions;
				$scope.regions = temp.filter(function(item, pos){
					return temp.indexOf(item)== pos;
				});
			}else if(data == "Canada"){

				vm.state = "Provinces";
			}
		}else{
			$rootScope.stateList = ['State'];
			$scope.states = $rootScope.stateList;
		}
	};
	vm.lockPreference = function () {
		$window.localStorage.setItem("healthyfling_preference","locked");
		$window.localStorage.setItem("healthyfling_preference_country",this.country);
		$window.localStorage.setItem("healthyfling_preference_state",this.state);
		$window.localStorage.setItem("healthyfling_preference_region",this.region);
		$window.localStorage.setItem("healthyfling_preference_category",this.category);
		$rootScope.savedPreference = true;
		vm.savedPreference = true;
		$scope.savedPreference = "locked";
		FlashService.Success("Search preference saved for easier browsing.");

	};
	vm.unlockPreference = function () {
		$window.localStorage.setItem("healthyfling_preference","unlocked");

		vm.country = $rootScope.search.country = "Country";
		vm.state = $rootScope.search.state = "State";
		vm.region = $rootScope.search.region = "Region";
		vm.category = $rootScope.search.category = "Category";

		$rootScope.savedPreference = false;
		vm.savedPreference = false;
		$scope.savedPreference = "unlocked";
		FlashService.Success("Search preference has been deleted.");

	};
	vm.search = function () {
		$rootScope.loading = true;

		$rootScope.search.country = this.country;
		$rootScope.search.state = this.state;
		$rootScope.search.region = this.region;
		$rootScope.search.category = this.category;
		vm.dataLoading = true;

		$location.path('/search');
	};
}]);
