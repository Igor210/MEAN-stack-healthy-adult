$( function() {
    $( "#state" ).selectmenu();
    $( "#region" ).selectmenu();
    $( "#category" ).selectmenu();
    $( "#slct_st" ).selectmenu();
    $( "#slct_reg" ).selectmenu();
    $( "#slct_catg" ).selectmenu();
    $( "#slct_loc" ).selectmenu();
    $( "#slct_age" ).selectmenu();
});
